package mvc.member.dao;

import mvc.member.dto.MemberDTO;

public interface MemberDAO {
	
	public int idCheck(String strId); //�ߺ�Ȯ�� üũ
	
	public int insert(MemberDTO dto); //ȸ������
	
	public MemberDTO getMember(String id);
}	
