package mvc.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import mvc.member.dto.MemberDTO;

public class MemberDAOImpl implements MemberDAO {

	DataSource dataSource; //���ؼ� ��ü�� ����
	
	//�̱��� ��� : ��ü�� 1���� �����ϰڴ�. (private ��ü�����ϰڴ�)
	private static MemberDAOImpl instance = new MemberDAOImpl();
	
	//static �̹Ƿ� Ŭ������.�޼ҵ�(): MemberDAOImpl getInstance();
	// return new MemberDAOImpl();
	public static MemberDAOImpl getInstance(){
		return instance;
	}
	
	//������
	public MemberDAOImpl(){
		try{
			/*
			 * ���ؼ� Ǯ(DBCP): Servers > context.xml
			 */
			
			Context context = new InitialContext();
	//                                                          |name�κ�-------|		
		dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); 
		//���ؼ�Ǯ�� �̸�(Ű���̵�)�� ã�ƿ��ڴ� -> datasource�� ��Ҵ�.
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	// �ߺ�Ȯ��
	@Override
	public int idCheck(String strId) {
		int cnt =0;
		
		Connection conn = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		
		try{
			conn=dataSource.getConnection(); //���ؼǿ� ����
			
			String sql = "SELECT * FROM mvc_member WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs =pstmt.executeQuery();
			
		
			
			// �Է¹��� id�� DB�� �����ϸ� cnt:1, �� id �ߺ�, �������� ������ cnt:0
			if(rs.next()){
				cnt = 1;
			}else{
				cnt = 0;
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(rs !=null) rs.close();
				if(pstmt != null)pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e2){
				e2.printStackTrace();
			}
		}
		return cnt; //return�� cnt�� �ٲ�����Ѵ�!! �߿� ***************
	}

	//ȸ������
	@Override
	public int insert(MemberDTO dto) {
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try{
			conn = dataSource.getConnection();
			
			String sql = "INSERT INTO mvc_member(id, pwd, name, jumin1, jumin2, hp, email,reg_date) VALUES(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			
			// �ٱ��Ͽ��� ������ set -> executeUpdate(); -> cnt�� ����
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getJumin1());
			pstmt.setString(5, dto.getJumin2());
			pstmt.setString(6, dto.getHp());
			pstmt.setString(7, dto.getEmail());
			pstmt.setTimestamp(8, dto.getRegi_date());
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e){
			e.printStackTrace();
			e.getMessage();
		}finally{
			
			try{
				if(pstmt!=null) pstmt.close();
				if(conn!= null) conn.close();
				
			}catch(SQLException e2){
				e2.printStackTrace();
				e2.getMessage();
			}
		}
		return cnt;
	}
	
	public int loginCheck(String id, String pwd){
		int cnt = 0;
		
		Connection conn = null;
		PreparedStatement pstmt =null;
		ResultSet rs = null;
		
		try{
			conn=dataSource.getConnection(); //���ؼǿ� ����
			String sql = "SELECT pwd FROM mvc_member WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs =pstmt.executeQuery();
			if(rs.next()){
				if(pwd.equals(rs.getString("pwd"))){
					cnt = 2;
				}else{
					cnt = -1;
				}
			}else{
				cnt = 0;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(rs !=null) rs.close();
				if(pstmt != null)pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e2){
				e2.printStackTrace();
			}
		}
		return cnt; 
	}
	
	public int delete(String id, String pwd){
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt =null;
		
		try{
			conn=dataSource.getConnection(); //���ؼǿ� ����
			String sql = "DELETE mvc_member WHERE id=? AND pwd = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			cnt = pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(pstmt != null)pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e2){
				e2.printStackTrace();
			}
		}
		return cnt; 
	}
	
	public int modify(MemberDTO dto){
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt =null;
		try{
			conn=dataSource.getConnection(); //���ؼǿ� ����
			String sql = "UPDATE mvc_member SET pwd = ?, hp = ?, email = ? WHERE id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getPwd());
			pstmt.setString(2, dto.getHp());
			pstmt.setString(3, dto.getEmail());
			pstmt.setString(4, dto.getId());
			cnt = pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if(pstmt != null)pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e2){
				e2.printStackTrace();
			}
		}
	return cnt;	
	}

	@Override
	public MemberDTO getMember(String id) {
		MemberDTO dto = new MemberDTO();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try{
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_member WHERE id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
			
			if(rs.next()){
				dto.setId(rs.getString("id"));
				dto.setPwd(rs.getString("pwd"));
				dto.setName(rs.getString("name"));
				dto.setJumin1(rs.getString("jumin1"));
				dto.setJumin2(rs.getString("jumin2"));
				dto.setHp(rs.getString("hp"));
				dto.setEmail(rs.getString("email"));
			}
		}catch(SQLException e1){
			e1.printStackTrace();
		}finally{
			try{
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e2){
				e2.printStackTrace();
			}
		}
		
		return dto;
	}
}
