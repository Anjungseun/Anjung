package mvc.member.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.member.dao.MemberDAO;
import mvc.member.dao.MemberDAOImpl;

public class LoginProHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) {
		MemberDAOImpl dao = MemberDAOImpl.getInstance();
		String id = req.getParameter("id");
		String pwd = req.getParameter("passwd");
		int cnt = dao.loginCheck(id, pwd);
		if(cnt == 2){
			req.getSession().setAttribute("memId", id);
		}
		req.setAttribute("cnt", cnt);
		System.out.println(cnt);
		return "/member/main.jsp";
	}
	
}
