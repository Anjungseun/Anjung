package mvc.member.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class loginFormHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) {
		
		int cnt = Integer.parseInt(req.getParameter("cnt"));
		
		req.setAttribute("cnt", cnt);
		
		return "/member/main.jsp";
	}

}
