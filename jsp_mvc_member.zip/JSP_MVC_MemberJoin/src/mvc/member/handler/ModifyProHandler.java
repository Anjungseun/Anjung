package mvc.member.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.member.dao.MemberDAOImpl;
import mvc.member.dto.MemberDTO;

public class ModifyProHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) {
		String id = (String)req.getSession().getAttribute("memId");
		String pwd = req.getParameter("pwd");
		MemberDAOImpl dao = MemberDAOImpl.getInstance();
		int cnt = dao.loginCheck(id, pwd);
		/*System.out.println(cnt);*/
		req.setAttribute("cnt", cnt);
		if(cnt == 2){
			MemberDTO dto = dao.getMember(id);
			req.setAttribute("dto", dto);
		}
		
		return "/member/modifyPro.jsp";
	}
}
