package mvc.member.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.member.dao.MemberDAO;
import mvc.member.dao.MemberDAOImpl;

public class DeleteProHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) {
		String id = (String)req.getSession().getAttribute("memId");
		String pw = req.getParameter("pwd");
		System.out.println(id);
		System.out.println(pw);
		/*cnt=2*/
		MemberDAOImpl dao = MemberDAOImpl.getInstance();
		/*dao.idCheck(strId);*/
		int check = dao.loginCheck(id, pw);
		int cnt = 0;
		if(check == 2){
			cnt = dao.delete(id, pw);
		}
		req.setAttribute("cnt", cnt);
		return "/member/deletePro.jsp";
	}
}
