package mvc.member.handler;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.member.dao.MemberDAOImpl;
import mvc.member.dto.MemberDTO;

public class ModifySendHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) {
		MemberDTO dto = new MemberDTO();
	    
		dto.setId((String)req.getSession().getAttribute("memId")); 
		dto.setPwd(req.getParameter("pwd"));
		dto.setName(req.getParameter("name"));
		// �ڵ���
		String hp1 = req.getParameter("hp1");
		String hp2 = req.getParameter("hp2");
		String hp3 = req.getParameter("hp3");
		
		if(!(hp1.equals("") && hp2.equals("") && hp3.equals(""))){
			String hp = hp1 + "-" + hp2 + "-"+ hp3 ; 
			dto.setHp(hp);
		}
			// �̸���
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		System.out.println(email2);
		
		String email = "";
		email = email1 + "@" + email2;
			
		dto.setEmail(email);
			// reg_date
		dto.setRegi_date(new Timestamp(System.currentTimeMillis()));
		
		MemberDAOImpl dao = MemberDAOImpl.getInstance();
		int cnt = dao.modify(dto);
		req.setAttribute("cnt", cnt);
		return "/member/modifySend.jsp";
	}

}
