package mvc.member.comtroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.member.handler.ConfirmIdHandler;
import mvc.member.handler.DeleteProHandler;
import mvc.member.handler.InputProHandler;
import mvc.member.handler.LoginProHandler;
import mvc.member.handler.LogoutHandler;
import mvc.member.handler.ModifyProHandler;
import mvc.member.handler.ModifySendHandler;
import mvc.member.handler.loginFormHandler;

@WebServlet("*.do")//�տ� � ������ �͵� .do�� �����ϰڴ�.
public class MFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public MFrontController() {
        super();
    }

	// 1�ܰ� : HTTP ��û�� �ްڴ�.
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		actionDo(req,res);
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		System.out.println("post �߻�");
		actionDo(req,res);
	}

	
	public void actionDo(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String viewPage = null;
		String uri = req.getRequestURI(); /* ��)  /JSP_MVC_MemberJoin/main.do  */
		String contextPath = req.getContextPath(); /*������Ʈ��   /JSP_MVC_MemberJoin */
		/*StringBuffer aaa = req.getRequestURL();
		System.out.println(aaa);
		System.out.println(uri);
		System.out.println(contextPath);*/
		String url = uri.substring(contextPath.length()); /*  /main.do   */
		
		if(url.equals("/main.do")){
			System.out.println("/member/main.jsp");
			req.setAttribute("cnt", 2); // �α����ϼ���
			viewPage = "/member/main.jsp";
			
		}else if(url.equals("/inputForm.do")){
			System.out.println("/member/inputForm.jsp");
			System.out.println(url);
			viewPage= "/member/inputForm.jsp";
			
		}else if(url.equals("/confirmId.do")){
			System.out.println("/member/confirmId.jsp");
			ConfirmIdHandler handler = new ConfirmIdHandler();
			viewPage = handler.process(req, res); // �𵨿����� �ϴ� ���񽺸� ȣ��!
			
		}else if(url.equals("/inputPro.do")){
			System.out.println("/member/inputPro.jsp");
			InputProHandler handler = new InputProHandler();
			viewPage =  handler.process(req, res);
			
		}else if(url.equals("/loginForm.do")){
			System.out.println("/member/loginForm.jsp/login");
			viewPage = "member/loginForm.jsp";
			loginFormHandler handler = new loginFormHandler();
			viewPage = handler.process(req, res);
		}else if(url.equals("/mainSuccess.do")){
			
			System.out.println("/member/main.jsp/logsuccess");
			req.setAttribute("cnt", 1); //ȸ�������� �����մϴ�.
			viewPage = "/member/main.jsp";
			
		}else if(url.equals("/loginPro.do")){
			System.out.println("member/main.jsp/logpro");
			LoginProHandler handler = new LoginProHandler();
			viewPage = handler.process(req, res);
			
		}else if(url.equals("/logout.do")){
			System.out.println("member/main.jsp/logout");
			LogoutHandler handler = new LogoutHandler();
			viewPage = handler.process(req, res);
			req.setAttribute("cnt", 2);
			
		}else if(url.equals("/deleteForm.do")){
			System.out.println("member/deleteFrom.jsp");
			viewPage = "/member/deleteForm.jsp";
			
		}else if(url.equals("/deletePro.do")){
			System.out.println("member/deletePro.jsp");
			DeleteProHandler handler = new DeleteProHandler();
			viewPage = handler.process(req, res);
			req.getSession().invalidate();
			
		}else if(url.equals("/modifyForm.do")){
			System.out.println("member/modifyFrom.jsp");
			viewPage = "/member/modifyForm.jsp";
			
		}else if(url.equals("/modifyPro.do")){
			System.out.println("member/modifyPro.jsp");
			ModifyProHandler handler = new ModifyProHandler();
			viewPage = handler.process(req, res);
			
		}else if(url.equals("/modifySend.do")){
			System.out.println("member/modifySend.jsp");
			ModifySendHandler handler = new ModifySendHandler();
			viewPage = handler.process(req, res);
		}
		
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}
	
}
