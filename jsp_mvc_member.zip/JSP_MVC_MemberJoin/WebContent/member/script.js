/**
 * validation check
 */
var msg_id="아이디를 입력하세요";
var msg_pwd="비밀번호를 입력하세요";
var msg_repwd ="비밀번호 확인을 입력하세요";
var msg_repwdChk="비밀번호가 일치하지 않습니다.";
var msg_name="이름을 입력하세요";
var msg_birth="주민번호를 입력하세요";
var msg_email="이메일을 입력하세요";
var msg_emailChk="이메일 형식에 맞지 않습니다";
var msg_confirmId="중복확인을 해주세요";
var insertError = "회원가입에 실패했습니다.\n잠시후 다시 시도하세요!";

function errorAlert(msg){
	alert(msg);
	window.history.back();
	
}


function mainFocus(){
	document.mainform.id.focus();	
	}

//메인화면 버튼 클릭시
function mainCheck(){
	if(!document.mainform.id.value){
		alert(msg_id);
		document.mainform.id.focus();
		return false;
	} else if(!document.mainform.passwd.value){
		alert(msg_pwd);
		document.mainform.passwd.focus();
		return false;
		
	}
	
}
//회원가입 페이지
function inputFocus(){
	document.inputform.id.focus();
}

//회원가입 버튼 클릭 시 
function inputCheck(){
	document.inputform.mail2.disabled = false;
	if(!document.inputform.id.value){
		alert(msg_id);
		document.inputform.id.focus();
		return false;
	
	}else if(!document.inputform.pwd.value){
		alert(msg_pwd);
		document.inputform.pwd.focus();
		return false;
		
	}else if(!document.inputform.repwd.value){
		alert(msg_repwd);
		document.inputform.repwd.focus();
		return false;
		
	}else if(document.inputform.pwd.value != document.inputform.repwd.value){
		alert(msg_repwdChk);
		document.inputform.pwd.focus();
		return false;
		
	}else if(!document.inputform.name.value){
		alert(msg_name);
		document.inputform.name.focus();
		return false;
		
	}else if(!document.inputform.jumin1.value){
		alert(msg_birth);
		document.inputform.jumin1.focus();
		return false;
		
	}else if(!document.inputform.jumin2.value){
		alert(msg_birth);
		document.inputform.jumin2.focus();
		return false;
		
	}else if(!document.inputform.email1.value){
		alert(msg_email);
		document.inputform.email1.focus();
		return false;
		
	}else if(!document.inputform.email2.value){
		alert(msg_email);
		document.inputform.email2.focus();
		return false;
	
	//직접 입력
	}else if(document.inputform.email3.value == 0 && !document.inputform.email2.value){
		alert(msg_email);
		document.inputform.email2.focus();
		return false;
		
	// 중복확인 버튼을 클릭하지 않은 경우	
	// 체크 전제조건 : inputform.jsp 의 form안에 <input type="hidden" name="hiddenId" value="0"> 추가함.
	}else if(document.inputform.hiddenId.value == 0){
		alert(msg_confirmId);
		document.inputform.dupChk.focus();
		return false;
	}
	
}

//중복확인
function confirmId(){
	if(!document.inputform.id.value){
		alert(msg_id);
		document.inputform.id.focus();
		return false;
	}
	// window.open("파일명","window명","창속성");
	// url="주소?속성=" + 속성값; get방식은 중간에 공백이 있으면 안된다.
	var url = "confirmId.do?id="+ document.inputform.id.value;
	window.open(url, "confirm", "menubar=no, width=300, height=200");
	
}

// 아이디 입력안했을 때 입력해라! 메세지 띄운다.
function confirmIdCheck(){
	if(!document.confirmform.id.value){
		alert(msg_id);
		document.confirmform.id.focus();
		return false;
	}
	
}

// opener : window객체의 open()메소드로 열린 새창(=중복확인창)에서, 열어준 부모창(=회원가입)에 접근할 때 사용 :부모 / self :자식 
// self.close(); 메세지 없이 현재창을 닫을 때 사용
function setId(id){
	opener.document.inputform.id.value=id;
	opener.document.inputform.hiddenId.value="1";
	self.close();
	
}

function nextJumin1(){
	if(document.inputform.jumin1.value.length >= 6){
		document.inputform.jumin2.focus();
	}
	return false;
	
}

function nextJumin2(){
	if(document.inputform.jumin2.value.length >= 6){
		document.inputform.hp1.focus();
	}
	return false;
}

function nextHp1(){
	if(document.inputform.hp1.value.length>=3){
		document.inputform.hp2.focus();
	}
	return false;
}

function nextHp2(){
	if(document.inputform.hp2.value.length>=4){
		documet.inputform.hp3.focus();
	}
	return false;
}

function nextHp3(){
	if(document.inputform.hp3.value.length>=4){
		document.inputform.email1.focus();
	}
	return false;
}

function passwdCheck(){
	if(!document.checkform.pwd.value){
		alert("비밀번호를 입력하세요")
	return false;	
	}
}

function change(){
	var email2 = document.inputform.email2;
	var email3 = document.inputform.email3;
	if(email3.value == "direct"){
		email2.value = "";
		email2.disabled = false;
		email2.focus();
	}
	if(email3.value == "gmail.com"){
		email2.value = "gmail.com";
	}
	if(email3.value == "naver.com"){
		email2.value = "naver.com";
	}
	if(email3.value == "hanmail.net"){
		email2.value = "hanmail.net"
	}
	if(email3.value == "nate.com"){
		email2.value = "nate.com";			
	}
}

function moCheck(){
	document.modifyform.email2.disabled = false;
	
	if(!document.modifyform.pwd.value){
		alert(msg_pwd);
		document.modifyform.pwd.focus();
		return false;
		
	}else if(!document.modifyform.repwd.value){
		alert(msg_repwd);
		document.modifyform.repwd.focus();
		return false;
		
	}else if(document.modifyform.pwd.value != document.modifyform.repwd.value){
		alert(msg_repwdChk);
		document.modifyform.pwd.focus();
		return false;
		
	}else if(!document.modifyform.email1.value){
		alert(msg_email);
		document.modifyform.email1.focus();
		return false;
		
	}else if(!document.modifyform.email2.value){
		alert(msg_email);
		document.modifyform.email2.focus();
		return false;
	
	}else if(document.modifyform.email3.value == 0 && !document.modifyform.email2.value){
		alert(msg_email);
		document.modifyform.email2.focus();
		return false;
		
	}else if(document.modifyform.hiddenId.value == 0){
		alert(msg_confirmId);
		document.modifyform.dupChk.focus();
		return false;
	}
	
}

function mochange(){
	var email2 = document.modifyform.email2;
	var email3 = document.modifyform.email3;
	if(email3.value == "direct"){
		email2.value = "";
		email2.disabled = false;
		email2.focus();
	}
	if(email3.value == "gmail.com"){
		email2.value = "gmail.com";
		email2.disabled = true;
	}
	if(email3.value == "naver.com"){
		email2.value = "naver.com";
		email2.disabled = true;
	}
	if(email3.value == "hanmail.net"){
		email2.value = "hanmail.net"
		email2.disabled = true;
	}
	if(email3.value == "nate.com"){
		email2.value = "nate.com";			
		email2.disabled = true;
	}
}